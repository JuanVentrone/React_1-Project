import React from 'react';

const Header = () => <div>Header</div>;

export default Header;
