import React from 'react';
import ReactDOM from 'react-dom';
import App from './container/App';

ReactDOM.render(
  <App />,
  document.getElementById('app')
);
